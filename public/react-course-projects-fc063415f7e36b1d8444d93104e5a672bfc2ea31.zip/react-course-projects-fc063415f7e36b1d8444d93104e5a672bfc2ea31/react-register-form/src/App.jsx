// import RegisterHook from "./components/form/RegisterHook";
// import RegisterFormik from "./components/form/RegisterFormik";

function App() {
  return (
    <div className="App">
      {/* <RegisterFormik></RegisterFormik> */}
      {/* <RegisterHook></RegisterHook> */}
    </div>
  );
}

export default App;
