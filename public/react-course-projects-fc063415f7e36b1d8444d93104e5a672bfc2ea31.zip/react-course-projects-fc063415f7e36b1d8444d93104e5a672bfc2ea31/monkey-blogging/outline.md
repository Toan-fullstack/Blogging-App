<!-- 1. Cài đặt Project Boilerplate Monkey Blogging
2. Thiết lập Firebase
3. Thiết lập Routes
4. Viết auth-context để lưu trữ thông tin User
5. Code trang SignUp - UI
6. Code trang SignUp - React hook form
7. Code trang SignUp - Authentication với Firebase
8. Sử dụng PropTypes và comment params cho component
9. Login UI
10. Header UI
11. Homepage UI
-->

12. Details UI
13. Dashboard UI
14. Add post Form
15. Routing dynamic import
16. Update post Form
17. Table UI
18. Category
19. Users
20. 404
21. Checkbox, radio, toggle
