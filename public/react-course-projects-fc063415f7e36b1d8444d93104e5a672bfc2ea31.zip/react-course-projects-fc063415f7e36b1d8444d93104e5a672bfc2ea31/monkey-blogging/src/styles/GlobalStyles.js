import { createGlobalStyle } from "styled-components";
import { GlobalClasses } from "./GlobalClasses";
export const GlobalStyles = createGlobalStyle`
  ${GlobalClasses}
`;
