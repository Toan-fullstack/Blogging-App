const { default: Table } = require("./Table");
export { Table };
